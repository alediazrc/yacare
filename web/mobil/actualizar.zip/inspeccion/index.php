<?php
    require_once '../global.php.inc';
    require_once '../head.php.inc';
    
    header('Location: listado.php');
?>

<script type="text/javascript">
window.location='listado.php';
</script>

<?php
    require_once '../footer.php.inc';
?>
</html>
