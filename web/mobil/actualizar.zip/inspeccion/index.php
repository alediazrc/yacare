<?php
    require_once '../global.php.inc';
    require_once '../head.php.inc';
?>

<script type="text/javascript">
window.setTimeout(RedireccionarSinc, 500);
function RedireccionarSinc() {
    window.location='listado.php';
}
window.location='listado.php';
</script>

<?php
    require_once '../head.php.inc';
?>
</html>
