#!/bin/sh
zip -r actualizar.zip * --exclude \*.sqlite debug\*
